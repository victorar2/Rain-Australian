##########################################################
# Create data set, Will rain tomorrow on Australian
##########################################################
if(!require(tidyverse)) install.packages("tidyverse", repos = "http://cran.us.r-project.org")
if(!require(caret)) install.packages("caret", repos = "http://cran.us.r-project.org")
if(!require(data.table)) install.packages("data.table", repos = "http://cran.us.r-project.org")
if(!require(gplots)) install.packages("data.table", repos = "http://cran.us.r-project.org")
if(!require(corrplot)) install.packages("data.table", repos = "http://cran.us.r-project.org")

library(tidyverse)
library(caret)
library(data.table)
library(gplots)
library(corrplot)
  # https://www.kaggle.com/jsphyg/weather-dataset-rattle-package/download

archive <- tempfile()
download.file("https://raw.githubusercontent.com/victorar2/MovieLensProject/f7cb001e1f815d1c5b504ed1111cd2319df5c22d/weatherAUS.csv",archive)
dataset<-read.csv(archive)

#summary of data, to detect length of data, missing values
summary(dataset) # a summary of dataset
head(dataset)
dataset<-drop_na(dataset) # remove rows with any Na values
str(dataset) # check the class of variables

#as see there are variables as character, we will transform it to factor
dataset<-dataset%>%mutate_if(is.character,as.factor)

#Change Yes/No data into number to check correlation
dataset<-dataset%>%mutate(RainToday=ifelse(RainToday=="No",0,1))
dataset<-dataset%>%mutate(RainTomorrow=ifelse(RainTomorrow=="No",0,1))

#divide data into train and test, 20% of data to test
set.seed(1, sample.kind="Rounding")
test_index <- createDataPartition(y = dataset$RainTomorrow, times = 1, p = 0.2, list = FALSE)
train <- dataset[-test_index,]
test<-dataset[test_index,]


#make RMSE function

RMSE<- function(predicted,real){
    sqrt(mean((predicted-real)^2))
}


#triying to train a model with regresion, tree or random forest take to long due data size and complex
#It is better to do a data exploration first to indentify relationship  of variables

#first make a correlation matrix to check main variables, correlationm matrix only work with numeric columns


matr<-Filter(is.numeric, train) #prepare data for correlation matrix
M<-cor(matr)
corrplot(M, method="pie",type="upper")
corrplot(M, type="upper", method="number",number.font = 2)



tree1<-train(RainTomorrow~Cloud3pm+RainToday+Humidity3pm+Sunshine,data=train,method="rpart")
plot(tree1, margin = 0.1)

#modifying complex parameter betwen 0-0.05

tree1<-train(RainTomorrow~Cloud3pm+RainToday+Humidity3pm+Sunshine,data=train,method="rpart",tuneGrid = data.frame(cp = seq(0, 0.05, len = 30)))
plot(tree1, margin = 0.1)
plot(tree1$finalModel, margin = 0.1)
text(tree1$finalModel)

#the value is transformed into logical response, Rain or not
p1<-predict(tree1,test)


RMSE(p1,test$RainTomorrow)

#There still factor variables, we will analyze how factor variables affect RainTomorrow
factorvariables<-Filter(is.factor, train)
factorvariables<-factorvariables%>%mutate(RainTomorrow=train$RainTomorrow)

#table only with factor variables
head(factorvariables)


#check the average of factor variables
  factorvariables%>%group_by(Location)%>%summarize(RainTave=mean(RainTomorrow))%>%
    ggplot(aes(x=reorder(Location,-RainTave),y=RainTave,fill=RainTave))+
    geom_bar(stat="identity")+
    theme(axis.text.x=element_text(angle =90, vjust = 0.5))
  
  factorvariables%>%group_by(WindGustDir)%>%summarize(RainTave=mean(RainTomorrow))%>%
    ggplot(aes(x=reorder(WindGustDir,-RainTave),y=RainTave,fill=RainTave))+
    geom_bar(stat="identity")+
    theme(axis.text.x=element_text(angle =90, vjust = 0.5))
  
  factorvariables%>%group_by(WindDir9am)%>%summarize(RainTave=mean(RainTomorrow))%>%
    ggplot(aes(x=reorder(WindDir9am,-RainTave),y=RainTave,fill=RainTave))+
    geom_bar(stat="identity")+
    theme(axis.text.x=element_text(angle =90, vjust = 0.5))
  
  factorvariables%>%group_by(WindDir3pm)%>%summarize(RainTave=mean(RainTomorrow))%>%
    ggplot(aes(x=reorder(WindDir3pm,-RainTave),y=RainTave,fill=RainTave))+
    geom_bar(stat="identity")+
    theme(axis.text.x=element_text(angle =90, vjust = 0.5))

#Location seems to be the most influent variable, we will check the error againts Location
  
#p1<-predict(tree,train)
Location_error<-train%>%mutate(p1RainTomorrow=predict(tree1,train))%>%mutate(err=p1RainTomorrow-RainTomorrow)
Location_error<-Location_error%>%group_by(Location)%>%summarize(error=mean(err))
Location_error%>%
  ggplot(aes(x=reorder(Location,-error),y=error,fill=error))+
  geom_bar(stat="identity")+
  theme(axis.text.x=element_text(angle =90, vjust = 0.5))

#we are going to add it to the model to check if is an improvement on RMSE

p<-test%>%left_join(Location_error,by="Location")%>%mutate(p2=predict(tree1,test)+error)

#the value is transformed into logical response, Rain or not
p2<-ifelse(p$p2>0.5,1,0)

RMSE(p$p2,test$RainTomorrow)

#the firs model is keeping, without adding Location

#Define cut off ofr Rain Tomorrw "Yes" / "No"
p1_train<-predict(tree1,train)

cutoff <- function(c,v1,v2){
  p<-ifelse(v1>c,1,0)
  RMSE(p,v2)
}
RMSE_v<-sapply(seq(0.2,0.8,len=20),cutoff,v1=p1_train,v2=train$RainTomorrow)
plot(x=seq(0.2,0.8,len=20),y=RMSE_v)

Predicted<-predict(tree1,test)
Predicted<-ifelse(Predicted>0.5,1,0)
RMSE(Predicted,test$RainTomorrow)